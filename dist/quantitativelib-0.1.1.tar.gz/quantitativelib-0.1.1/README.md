# quantitativelib

A simple Python library to fetch stock data, plot prices and returns, and compute financial statistics.

This functions mainly as a test to learn how packages are made, and hopefully to develop a customised quantitative finance library suited to my needs